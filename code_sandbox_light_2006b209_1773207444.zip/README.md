# HEILUMI — Lighting Designer Network Platform

A refined, editorial-style website connecting lighting designers, collectors, and brands globally. Built with pure HTML, CSS, and JavaScript.

## 🌐 Live Website

**URL:** [To be deployed on Cloudflare Pages]

## 📋 Project Overview

HEILUMI is a global platform that bridges visionary lighting designers with the Asian market, particularly Korea. The website serves three primary audiences:

1. **Designers** — European and international lighting designers seeking production, marketing, and distribution support
2. **Collectors** — Interior stylists, architects, influencers, and design enthusiasts who curate spaces through lighting
3. **Brands** — Curated selection of global lighting brands (coming soon)

## ✨ Key Features

### Current Features

#### Home Page (/)
- Hero section with brand tagline: "Lighting Designer Meets Here"
- Five core services: Production, Certification, Marketing, Branding, Legal
- Featured designers and collectors preview
- Clean, white-background editorial aesthetic

#### Designers (/designers.html)
- Interactive world map (Leaflet.js) showing designer locations
- Click map pins to scroll to designer profiles
- Designer grid with black & white portrait photography
- Individual designer detail pages with:
  - Full biography
  - Social media links (Instagram, website)
  - Artwork gallery with lightbox viewer
  
**Current Designer:**
- David Jeong (Seoul, South Korea) — fully implemented with bio and 6 artworks

#### Collectors (/collectors.html)
- Featured collector profiles
- Slogan: "Our collectors create spaces through design"
- Individual collector detail pages with:
  - Biography and role
  - Instagram integration
  - Curated spaces gallery
  
**Current Collectors:**
- Mia Seo — Interior Stylist & Influencer (Seoul)
- Jonas Berger — Architect & Design Collector (Berlin)
- Yuna Park — Creative Director & Lifestyle Influencer (Seoul)

#### Brands (/brands.html) 🔒
- **Login Protected** (username: `admin`, password: `admin@2026`)
- Placeholder brand grid featuring: HAY, Foscarini, Flos, Artemide, Louis Poulsen, Muuto
- Note: Shopify integration planned for future phase

#### R&D Lab (/rnd.html) 🔒
- **Login Protected** (username: `admin`, password: `admin@2026`)
- Four R&D pillars:
  1. Design Dataset
  2. AI Generation
  3. Human Curation
  4. Robot Production
- Development progress bars (decorative, showing in-progress status)
- Status: Coming Soon

#### Contact (/contact.html)
- Two-column layout: office info + contact form
- **Office Address:**
  ```
  HEILUMI Studio
  322 Teheran-ro, Yeoksam-dong
  Gangnam-gu, Seoul 06211
  South Korea
  ```
- **Email:** roboholic84@gmail.com
- Form integration: Formspree (sends to roboholic84@gmail.com)
- Social media links (Instagram, LinkedIn)

### Design Philosophy

- **White background** throughout — no dark themes
- **Typography-forward**: Playfair Display (headings) + Inter (body)
- **Black & white photography** via CSS `grayscale(100%)` filter
- **Minimal, editorial aesthetic** inspired by HAY.com and Foscarini.com
- **Gallery-like presentation** — art magazine, not e-commerce
- **Generous whitespace** and subtle animations

### Technical Stack

- **HTML5** — Semantic markup
- **CSS3** — Custom styles, no frameworks (except Tailwind CDN for utility if needed)
- **JavaScript (Vanilla)** — No jQuery, pure ES6+
- **Leaflet.js** — Interactive world map
- **Font Awesome** — Icons
- **Google Fonts** — Playfair Display + Inter
- **Formspree** — Contact form backend

## 📁 File Structure

```
heilumi/
├── index.html                 # Home page
├── designers.html             # Designers directory
├── designer-detail.html       # Individual designer page
├── collectors.html            # Collectors directory
├── collector-detail.html      # Individual collector page (dynamic)
├── brands.html                # Brands page (login protected)
├── rnd.html                   # R&D Lab page (login protected)
├── contact.html               # Contact page
├── css/
│   └── styles.css            # Global styles
└── js/
    ├── main.js               # Core JavaScript (menu, lightbox, scroll)
    ├── auth.js               # Login system (sessionStorage)
    ├── map.js                # Leaflet map initialization
    └── collector-detail.js   # Collector data and rendering
```

## 🔐 Protected Pages

Two pages require authentication:

| Page | Username | Password |
|------|----------|----------|
| Brands | `admin` | `admin@2026` |
| R&D Lab | `admin` | `admin@2026` |

Authentication is stored in `sessionStorage` and persists during the browser session.

## 🚀 Deployment

### Cloudflare Pages

This project is designed to be deployed on **Cloudflare Pages** for:
- Fast global CDN delivery
- Optimal performance in Korea/Asia
- Free SSL certificate
- Custom domain support (heilumi.com)

**Deployment Steps:**
1. Push code to GitHub repository
2. Connect repository to Cloudflare Pages
3. Build settings: None (static HTML)
4. Deploy
5. Connect custom domain: heilumi.com

### Local Development

Simply open `index.html` in a browser, or use a local server:

```bash
# Python 3
python -m http.server 8000

# Node.js
npx http-server

# PHP
php -S localhost:8000
```

Then visit `http://localhost:8000`

## 🎨 Design System

### Colors
- **White**: `#FFFFFF` (main background)
- **Black**: `#000000` (text, headings)
- **Gray**: `#666666` (body text)
- **Light Gray**: `#e0e0e0` (borders, dividers)

### Typography
- **Headings**: Playfair Display (serif, bold/black weights)
- **Body**: Inter (sans-serif, 300-600 weights)
- **Base size**: 16-18px body text
- **Headings**: Fluid typography (clamp for responsive sizing)

### Spacing
- Generous padding/margins (80-120px section spacing)
- Thin 1px borders
- Minimal shadows

## 📝 Content Management

### Adding New Designers

1. Open `designers.html`
2. Add new card in the designer grid
3. Create corresponding detail page or update `designer-detail.html` to be dynamic
4. Add marker to `js/map.js`:
   ```javascript
   {
       name: 'Designer Name',
       country: 'Country',
       coords: [latitude, longitude],
       elementId: 'designer-id'
   }
   ```

### Adding New Collectors

1. Open `js/collector-detail.js`
2. Add new collector object to `collectors` array:
   ```javascript
   collectorId: {
       name: 'Name',
       role: 'Role',
       location: 'City, Country',
       instagram: '@handle',
       image: 'image-url',
       bio: ['paragraph 1', 'paragraph 2'],
       spaces: ['space1.jpg', 'space2.jpg']
   }
   ```
3. Add card in `collectors.html`

## 🔧 Configuration

### Email Contact Form

Currently configured to send to: **roboholic84@gmail.com** via Formspree

To change recipient:
- Update `action` attribute in `contact.html` form
- Use format: `https://formspree.io/f/YOUR_EMAIL`

### Login Credentials

To change admin credentials, edit `js/auth.js`:
```javascript
const ADMIN_USERNAME = 'admin';
const ADMIN_PASSWORD = 'admin@2026';
```

## 📱 Responsive Design

Breakpoints:
- **Desktop**: > 1024px (full layout)
- **Tablet**: 768px - 1024px (2-column grids)
- **Mobile**: < 768px (single column, hamburger menu)

All images use CSS grayscale filter and are responsive.

## 🚧 Roadmap / Not Yet Implemented

### Phase 2 (Planned)
- [ ] Shopify integration for Brands page
- [ ] Designer CMS (Notion API or Contentful)
- [ ] Multiple language support (Korean/English toggle)
- [ ] More designers and collectors
- [ ] Newsletter signup
- [ ] Blog/Stories section

### Phase 3 (Future)
- [ ] AI R&D Lab functional interface
- [ ] Designer application portal
- [ ] Collector community features
- [ ] E-commerce for limited editions

## 📞 Support

For questions or support:
- **Email**: roboholic84@gmail.com
- **Office**: 322 Teheran-ro, Yeoksam-dong, Gangnam-gu, Seoul, South Korea

## 📄 License

© 2025 HEILUMI. All rights reserved.

---

**Last Updated:** March 2026  
**Version:** 1.0.0  
**Status:** MVP Complete — Ready for Deployment