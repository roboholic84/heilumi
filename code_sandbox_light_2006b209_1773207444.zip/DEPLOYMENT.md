# HEILUMI — Cloudflare Pages Deployment Guide

## Quick Deploy to Cloudflare Pages

### Option 1: Direct Upload (Fastest)

1. **Go to Cloudflare Pages Dashboard**
   - Visit: https://dash.cloudflare.com/
   - Navigate to: Workers & Pages → Create application → Pages → Upload assets

2. **Upload Your Project**
   - Zip all project files (or upload the entire directory)
   - Click "Upload files" and select your project folder
   - Click "Deploy site"

3. **Your site is live!**
   - You'll receive a URL like: `heilumi-abc123.pages.dev`

### Option 2: GitHub Integration (Recommended)

1. **Push to GitHub**
   ```bash
   git init
   git add .
   git commit -m "Initial HEILUMI website"
   git remote add origin https://github.com/YOUR_USERNAME/heilumi.git
   git push -u origin main
   ```

2. **Connect to Cloudflare Pages**
   - Go to: https://dash.cloudflare.com/
   - Workers & Pages → Create application → Pages → Connect to Git
   - Select your repository
   - Configure build settings:
     - **Build command**: Leave empty (static site)
     - **Build output directory**: `/` (root)
   - Click "Save and Deploy"

3. **Automatic Deployments**
   - Every push to `main` branch will auto-deploy
   - Preview deployments for pull requests

### Option 3: Wrangler CLI

```bash
# Install Wrangler
npm install -g wrangler

# Login to Cloudflare
wrangler login

# Deploy
wrangler pages deploy . --project-name=heilumi
```

## Custom Domain Setup

### Add heilumi.com

1. **In Cloudflare Pages Dashboard**
   - Go to your project → Custom domains
   - Click "Set up a custom domain"
   - Enter: `heilumi.com`
   - Click "Continue"

2. **Update DNS Records**
   - Cloudflare will automatically add the required DNS records
   - Wait 5-10 minutes for propagation

3. **SSL Certificate**
   - Automatically provisioned by Cloudflare (free)
   - Usually active within minutes

### Add www subdomain

Repeat the process with `www.heilumi.com`

## Environment Variables (If Needed)

If you add any API keys or secrets in the future:

1. Go to: Project Settings → Environment variables
2. Add your variables (e.g., `FORMSPREE_KEY`)
3. Redeploy

## Performance Optimization

Cloudflare Pages automatically provides:
- ✅ Global CDN (200+ locations)
- ✅ Automatic image optimization
- ✅ Brotli compression
- ✅ HTTP/2 and HTTP/3
- ✅ DDoS protection
- ✅ Free SSL

### Additional Optimizations

Add a `_headers` file to the root:

```
/*
  X-Frame-Options: DENY
  X-Content-Type-Options: nosniff
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: camera=(), microphone=(), geolocation=()

/css/*
  Cache-Control: public, max-age=31536000, immutable

/js/*
  Cache-Control: public, max-age=31536000, immutable

/images/*
  Cache-Control: public, max-age=31536000, immutable
```

Add a `_redirects` file for URL handling:

```
# Redirect www to non-www
https://www.heilumi.com/* https://heilumi.com/:splat 301!

# 404 fallback
/* /index.html 404
```

## Analytics Setup

### Cloudflare Web Analytics (Free)

1. Go to: Analytics → Web Analytics
2. Click "Add a site"
3. Copy the tracking code
4. Add before `</body>` in all HTML files:

```html
<script defer src='https://static.cloudflareinsights.com/beacon.min.js' 
        data-cf-beacon='{"token": "YOUR_TOKEN"}'></script>
```

## Monitoring & Maintenance

### Check Deployment Status
- Dashboard: https://dash.cloudflare.com/
- View build logs
- Monitor traffic and performance

### Update Site

**Via GitHub:**
```bash
git add .
git commit -m "Update content"
git push
```
Auto-deploys in 30-60 seconds.

**Via Direct Upload:**
Re-upload files through Cloudflare Pages dashboard.

## Troubleshooting

### Images not loading
- Ensure all image URLs are HTTPS
- Check Content Security Policy

### Map not displaying
- Verify Leaflet.js CDN is accessible
- Check browser console for errors

### Forms not working
- Verify Formspree endpoint
- Check CORS settings

### Login not persisting
- Check if `sessionStorage` is enabled
- Test in incognito/private mode

## Support

- **Cloudflare Docs**: https://developers.cloudflare.com/pages/
- **Community**: https://community.cloudflare.com/
- **Status**: https://www.cloudflarestatus.com/

## Estimated Costs

- **Cloudflare Pages**: FREE
  - Unlimited requests
  - Unlimited bandwidth
  - 500 builds/month
  - 20,000 files

- **Custom Domain**: If not already using Cloudflare DNS
  - Free if domain is on Cloudflare
  - Otherwise, just DNS transfer (free)

## Next Steps After Deployment

1. ✅ Test all pages and functionality
2. ✅ Set up Cloudflare Web Analytics
3. ✅ Configure custom domain (heilumi.com)
4. ✅ Test contact form submissions
5. ✅ Verify login system for Brands/R&D
6. ✅ Check mobile responsiveness
7. ✅ Test map interactivity
8. ✅ Share with team for feedback

---

**Need Help?**  
Contact: roboholic84@gmail.com