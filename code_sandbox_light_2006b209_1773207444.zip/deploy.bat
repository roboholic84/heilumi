@echo off
REM HEILUMI - GitHub 자동 배포 스크립트 (Windows)
REM 사용법: deploy.bat 더블클릭

echo 🚀 HEILUMI GitHub 배포 시작...

REM 1. Git 초기화
if not exist .git (
    echo 📦 Git 초기화 중...
    git init
    git branch -M main
)

REM 2. 원격 저장소 설정
echo 🔗 GitHub 저장소 연결 중...
git remote remove origin 2>nul
git remote add origin https://github.com/roboholic84/heilumi.git

REM 3. 모든 파일 추가
echo 📁 파일 추가 중...
git add .

REM 4. 커밋
echo 💾 커밋 생성 중...
git commit -m "Initial HEILUMI website deployment"

REM 5. 푸시
echo ⬆️  GitHub에 푸시 중...
git push -u origin main --force

echo.
echo ✅ 배포 완료!
echo 🌐 Cloudflare Pages에서 자동으로 배포 시작합니다
echo 📱 약 30초 후 https://heilumi.pages.dev 에서 확인 가능합니다
echo.
pause