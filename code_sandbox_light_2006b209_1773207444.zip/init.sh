#!/bin/bash

# HEILUMI 자동 배포 스크립트
# 이 스크립트는 모든 파일을 자동으로 생성하고 GitHub에 푸시합니다

echo "🚀 HEILUMI 프로젝트 초기화 시작..."

# Git 초기화
git init
git branch -M main
git remote add origin https://github.com/roboholic84/heilumi.git

# 폴더 생성
mkdir -p css js

echo "📁 폴더 구조 생성 완료"
echo "📝 파일들을 다운로드하여 이 폴더에 저장해주세요"
echo ""
echo "파일 저장 후 아래 명령어를 실행하세요:"
echo "  git add ."
echo "  git commit -m 'Initial HEILUMI website'"
echo "  git push -u origin main"
echo ""
echo "✅ 준비 완료!"