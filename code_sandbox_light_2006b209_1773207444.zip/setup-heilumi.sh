#!/bin/bash

# =============================================================================
# HEILUMI 완전 자동 배포 스크립트
# =============================================================================
# 사용법: 
#   1. 빈 폴더에서 이 스크립트를 저장 (setup-heilumi.sh)
#   2. chmod +x setup-heilumi.sh
#   3. ./setup-heilumi.sh
# =============================================================================

echo "🚀 HEILUMI 프로젝트 자동 설치 시작..."
echo ""

# Git 설정 확인
if ! command -v git &> /dev/null; then
    echo "❌ Git이 설치되어 있지 않습니다"
    echo "   https://git-scm.com/download 에서 설치해주세요"
    exit 1
fi

# Git 초기화
echo "📦 Git 초기화 중..."
git init
git branch -M main
git remote add origin https://github.com/roboholic84/heilumi.git 2>/dev/null

# 폴더 구조 생성
echo "📁 폴더 구조 생성 중..."
mkdir -p css js

# 안내 메시지
echo ""
echo "✅ Git 설정 완료!"
echo ""
echo "📥 이제 다음 단계를 진행하세요:"
echo ""
echo "1️⃣  AI Developer 화면에서 파일들을 다운로드하세요"
echo "    (Export / Download 버튼 찾기)"
echo ""
echo "2️⃣  다운로드한 파일들을 현재 폴더에 복사하세요"
echo ""
echo "3️⃣  아래 명령어로 배포:"
echo "    git add ."
echo "    git commit -m 'Initial HEILUMI website'"
echo "    git push -u origin main --force"
echo ""
echo "4️⃣  30초 후 https://heilumi.pages.dev 에서 확인!"
echo ""
echo "💡 또는 이 폴더에 파일을 수동으로 만드신 후 위의 git 명령어를 실행하세요"
echo ""