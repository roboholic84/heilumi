# 🚀 HEILUMI - 빠른 배포 가이드

## ⚡ 1분만에 배포하기

### 📋 준비물
- ✅ Git 설치 (https://git-scm.com/download)
- ✅ GitHub 계정 로그인
- ✅ 프로젝트 파일 (이 폴더)

---

## 🎯 방법 1: 자동 스크립트 실행 (가장 쉬움)

### Mac/Linux:
```bash
bash deploy.sh
```

### Windows:
```
deploy.bat 더블클릭
```

**끝!** 30초 후 https://heilumi.pages.dev 접속

---

## 🔧 방법 2: 수동 명령어

터미널/명령 프롬프트에서:

```bash
# 1. Git 초기화
git init
git branch -M main

# 2. 원격 저장소 연결
git remote add origin https://github.com/roboholic84/heilumi.git

# 3. 파일 추가 및 커밋
git add .
git commit -m "Initial HEILUMI website"

# 4. 푸시
git push -u origin main
```

---

## 📱 방법 3: GitHub 웹 인터페이스

1. https://github.com/roboholic84/heilumi 접속
2. "Add file" → "Upload files" 클릭
3. 모든 파일을 드래그 앤 드롭
4. "Commit changes" 클릭

---

## ✅ 배포 확인

### Cloudflare Pages에서 확인:
1. https://dash.cloudflare.com/
2. Workers & Pages → heilumi
3. "Deployments" 탭에서 진행 상황 확인

### 배포 완료 후:
- 🌐 URL: https://heilumi.pages.dev
- ⏱️ 소요 시간: 약 30초 ~ 1분
- 📱 모바일에서 바로 접속 가능!

---

## 🔄 이후 업데이트 방법

파일을 수정한 후:

```bash
git add .
git commit -m "업데이트 내용"
git push
```

자동으로 Cloudflare가 재배포합니다!

---

## ❓ 문제 해결

### "git: command not found"
→ Git을 설치하세요: https://git-scm.com/download

### "Permission denied"
→ GitHub 로그인 필요:
```bash
git config --global user.email "roboholic84@gmail.com"
git config --global user.name "roboholic84"
```

### "Repository not found"
→ GitHub 저장소 확인: https://github.com/roboholic84/heilumi

---

## 📞 도움말

- 📧 Email: roboholic84@gmail.com
- 📖 전체 문서: README.md 참고
- 🚀 배포 가이드: DEPLOYMENT.md 참고

---

**마지막 업데이트: 2026-03-11**