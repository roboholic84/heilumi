// Collector detail page data and rendering

const collectors = {
    mia: {
        name: 'Mia Seo',
        role: 'Interior Stylist & Influencer',
        location: 'Seoul, South Korea',
        instagram: '@mia.seo.space',
        image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=500&fit=crop',
        bio: [
            'Mia Seo is a Seoul-based interior stylist and content creator who has transformed the way young Koreans think about domestic space. With a background in visual merchandising and a refined eye for composition, she curates environments that feel both aspirational and lived-in.',
            'Her Instagram account (@mia.seo.space) has become a reference point for minimalist Korean interiors, where lighting plays a central role. Mia collaborates with emerging designers to showcase how thoughtful illumination can redefine a room\'s character—turning corners into focal points and everyday objects into art.',
            'A collector of limited-edition lighting pieces, Mia believes that "light is the most honest medium—you can\'t fake atmosphere." Her spaces have been featured in Kinfolk, Wallpaper*, and Casa Brutus.'
        ],
        spaces: [
            'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=600',
            'https://images.unsplash.com/photo-1615529182904-14819c35db37?w=600',
            'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=600',
            'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?w=600',
            'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=600',
            'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=600'
        ]
    },
    jonas: {
        name: 'Jonas Berger',
        role: 'Architect & Design Collector',
        location: 'Berlin, Germany',
        instagram: '@jonas.berger.arch',
        image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=500&fit=crop',
        bio: [
            'Jonas Berger is a Berlin-based architect who treats lighting design as sculpture. With a practice focused on adaptive reuse and cultural spaces, he has become known for integrating carefully selected designer lighting into his architectural interventions.',
            'His collection spans from 1960s Italian classics to contemporary Nordic pieces, each chosen for its conceptual clarity and material honesty. For Jonas, a lighting piece must "hold its own as an object, even when turned off."',
            'His residential and commercial projects have been featured in Dezeen, ArchDaily, and Frame Magazine. He lectures at the Technical University of Berlin on the intersection of lighting and spatial experience.'
        ],
        spaces: [
            'https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=600',
            'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=600',
            'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=600',
            'https://images.unsplash.com/photo-1600607687644-c7171b42498f?w=600',
            'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=600',
            'https://images.unsplash.com/photo-1600210491892-03d54c0aaf87?w=600'
        ]
    },
    yuna: {
        name: 'Yuna Park',
        role: 'Creative Director & Lifestyle Influencer',
        location: 'Seoul, South Korea',
        instagram: '@yunapark.life',
        image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=500&fit=crop',
        bio: [
            'Yuna Park is a Seoul-based creative director and lifestyle influencer with over 200,000 followers. Her content explores the intersection of design, wellness, and everyday rituals—with lighting serving as a recurring motif.',
            'Trained in graphic design and brand strategy, Yuna approaches space-making with a storyteller\'s sensibility. She partners with lighting designers to create aspirational yet accessible interiors, documenting the process from concept to final installation.',
            'Her collaborations have led to sold-out limited editions and brought emerging designers to the attention of Korean audiences. Yuna believes that "the right light can change not just a room, but your entire day."'
        ],
        spaces: [
            'https://images.unsplash.com/photo-1600210492493-0946911123ea?w=600',
            'https://images.unsplash.com/photo-1600573472556-e636b92b0cec?w=600',
            'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=600',
            'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=600',
            'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=600',
            'https://images.unsplash.com/photo-1600566752355-35792bedcfea?w=600'
        ]
    }
};

// Load collector data based on URL parameter
document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const collectorId = urlParams.get('id');
    
    if (collectorId && collectors[collectorId]) {
        const collector = collectors[collectorId];
        renderCollectorDetail(collector);
    } else {
        // Redirect to collectors page if invalid ID
        window.location.href = 'collectors.html';
    }
});

function renderCollectorDetail(collector) {
    // Render main content
    const contentDiv = document.getElementById('collectorContent');
    contentDiv.innerHTML = `
        <div>
            <img src="${collector.image}" alt="${collector.name}" class="detail-image">
        </div>
        
        <div class="detail-info">
            <h1>${collector.name}</h1>
            <p class="detail-subtitle">${collector.role}</p>
            <p class="detail-subtitle">${collector.location}</p>
            
            <div class="detail-links">
                <a href="https://instagram.com/${collector.instagram.replace('@', '')}" target="_blank" title="Instagram">
                    <i class="fab fa-instagram"></i>
                </a>
            </div>
            
            <div class="detail-divider"></div>
            
            <div class="detail-bio">
                ${collector.bio.map(paragraph => `<p>${paragraph}</p>`).join('<p style="margin-top: 24px;"></p>')}
            </div>
        </div>
    `;
    
    // Render spaces gallery
    const galleryDiv = document.getElementById('spacesGallery');
    galleryDiv.innerHTML = collector.spaces.map((imgSrc, index) => `
        <div class="gallery-item" onclick="openLightbox(${index})">
            <img src="${imgSrc}" alt="${collector.name}'s space ${index + 1}">
        </div>
    `).join('');
    
    // Update subtitle
    const subtitle = document.getElementById('spacesSubtitle');
    subtitle.textContent = `Explore how ${collector.name} transforms space through light and design.`;
}