// Authentication system for protected pages

function handleLogin(event, page) {
    event.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorMessage = document.getElementById('errorMessage');
    
    // Credentials
    const ADMIN_USERNAME = 'admin';
    const ADMIN_PASSWORD = 'admin@2026';
    
    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
        // Store authentication in sessionStorage
        sessionStorage.setItem('heilumi_auth', 'true');
        sessionStorage.setItem('heilumi_auth_page', page);
        
        // Hide login modal and show main content
        document.getElementById('loginModal').style.display = 'none';
        document.getElementById('mainContent').style.display = 'block';
        
        errorMessage.style.display = 'none';
    } else {
        // Show error message
        errorMessage.style.display = 'block';
    }
    
    return false;
}

// Check if user is already authenticated
document.addEventListener('DOMContentLoaded', function() {
    const isAuthenticated = sessionStorage.getItem('heilumi_auth') === 'true';
    
    if (isAuthenticated) {
        document.getElementById('loginModal').style.display = 'none';
        document.getElementById('mainContent').style.display = 'block';
    }
});