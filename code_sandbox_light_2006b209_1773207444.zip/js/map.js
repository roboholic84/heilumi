// Interactive map for designers page

document.addEventListener('DOMContentLoaded', function() {
    // Initialize map
    const map = L.map('map', {
        center: [37.5665, 126.9780], // Seoul coordinates
        zoom: 3,
        zoomControl: true,
        scrollWheelZoom: false
    });
    
    // Use CartoDB Positron tiles (light, minimal style)
    L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
        subdomains: 'abcd',
        maxZoom: 19
    }).addTo(map);
    
    // Custom marker icon (simple black circle)
    const customIcon = L.divIcon({
        className: 'custom-marker',
        html: '<div style="width: 12px; height: 12px; background-color: #000; border-radius: 50%; border: 2px solid white; box-shadow: 0 2px 8px rgba(0,0,0,0.3);"></div>',
        iconSize: [12, 12],
        iconAnchor: [6, 6]
    });
    
    // Designer locations
    const designers = [
        {
            name: 'David Jeong',
            country: 'South Korea',
            coords: [37.5665, 126.9780], // Seoul
            elementId: 'designer-david'
        }
        // Add more designers here as needed
    ];
    
    // Add markers
    designers.forEach(designer => {
        const marker = L.marker(designer.coords, { icon: customIcon })
            .addTo(map)
            .bindTooltip(`${designer.name}<br><small>${designer.country}</small>`, {
                permanent: false,
                direction: 'top',
                className: 'custom-tooltip',
                offset: [0, -10]
            });
        
        // Click handler to scroll to designer profile
        marker.on('click', function() {
            const element = document.getElementById(designer.elementId);
            if (element) {
                // Close mobile menu if open
                const navMenu = document.getElementById('navMenu');
                if (navMenu) navMenu.classList.remove('active');
                
                // Smooth scroll to designer card
                element.scrollIntoView({
                    behavior: 'smooth',
                    block: 'center'
                });
                
                // Highlight effect
                element.style.transform = 'scale(1.05)';
                setTimeout(() => {
                    element.style.transform = 'scale(1)';
                }, 300);
            }
        });
    });
});

// Add custom tooltip styles
const style = document.createElement('style');
style.textContent = `
    .custom-tooltip {
        background-color: white !important;
        border: 1px solid #000 !important;
        color: #000 !important;
        font-family: 'Inter', sans-serif !important;
        font-size: 14px !important;
        padding: 8px 12px !important;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15) !important;
    }
    
    .custom-tooltip::before {
        border-top-color: #000 !important;
    }
    
    .leaflet-container {
        background-color: #f5f5f5 !important;
    }
`;
document.head.appendChild(style);