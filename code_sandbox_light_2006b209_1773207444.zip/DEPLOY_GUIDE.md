# 🚀 HEILUMI 원클릭 배포 가이드

## ⚡ 가장 빠른 방법 (5분 완성)

### 🎯 준비물
- ✅ Git 설치 (https://git-scm.com)
- ✅ 터미널/명령 프롬프트
- ✅ GitHub 계정 (roboholic84)

---

## 📋 3단계로 완료

### 1️⃣ 프로젝트 다운로드

**현재 AI Developer 화면에서:**

- 우측 상단 **"Export"** 또는 **"Download"** 클릭
- 또는 좌측 메뉴 **"..."** → **"Download all files"**
- `heilumi.zip` 다운로드

**압축 해제:**
```bash
unzip heilumi.zip
cd heilumi
```

---

### 2️⃣ GitHub에 푸시 (한 번만)

```bash
# Git 초기화
git init
git branch -M main

# 원격 저장소 연결
git remote add origin https://github.com/roboholic84/heilumi.git

# 모든 파일 추가
git add .

# 커밋
git commit -m "Initial HEILUMI website - Complete deployment"

# 푸시
git push -u origin main --force
```

**비밀번호 대신 Personal Access Token 사용:**
- GitHub → Settings → Developer settings → Personal access tokens
- 또는 `gh auth login` 사용

---

### 3️⃣ 자동 배포 확인

**GitHub에 푸시하면 자동으로:**
1. ✅ Cloudflare Pages가 감지
2. ✅ 자동으로 빌드 시작
3. ✅ 30초 후 배포 완료
4. ✅ https://heilumi.pages.dev 접속 가능!

---

## 🔄 이후 업데이트 (자동 배포)

파일을 수정한 후:

```bash
git add .
git commit -m "업데이트 내용"
git push
```

**끝!** Cloudflare가 자동으로 재배포합니다.

---

## 🛠️ 대안: Wrangler CLI 사용

### 설치 (한 번만):
```bash
npm install -g wrangler
wrangler login
```

### 배포 (매번):
```bash
wrangler pages deploy . --project-name=heilumi
```

**장점:**
- GitHub 없이 직접 배포 가능
- 더 빠름 (10초)
- 로컬에서 바로 업로드

---

## 📱 배포 확인

### Cloudflare Dashboard:
https://dash.cloudflare.com/ → Workers & Pages → heilumi

### 확인 사항:
- ✅ Deployment status: Success
- ✅ URL: https://heilumi.pages.dev
- ✅ Last deployed: (최신 시간)

---

## 🎉 완료!

이제 파일만 수정하고 `git push` 하면:
- ✅ 자동으로 Cloudflare 배포
- ✅ 30초 후 업데이트 반영
- ✅ 모바일에서 즉시 확인 가능

---

## 💡 Pro Tips

### Git 자격증명 저장:
```bash
git config --global credential.helper store
git config --global user.email "roboholic84@gmail.com"
git config --global user.name "roboholic84"
```

### 한 번에 업데이트:
```bash
# 별칭 만들기
alias deploy="git add . && git commit -m 'Update' && git push"

# 사용
deploy
```

### 롤백 (이전 버전으로):
```bash
git revert HEAD
git push
```

---

## ❓ 문제 해결

### "authentication failed"
→ Personal Access Token 사용:
- GitHub → Settings → Developer settings
- Generate new token (classic)
- 권한: repo 전체 체크
- 복사한 토큰을 비밀번호 대신 입력

### "Permission denied"
→ SSH 키 설정:
```bash
ssh-keygen -t ed25519 -C "roboholic84@gmail.com"
cat ~/.ssh/id_ed25519.pub
# GitHub → Settings → SSH keys에 추가
```

### "Cloudflare 배포 실패"
→ Cloudflare Dashboard에서 로그 확인:
- Workers & Pages → heilumi → Deployments
- 실패한 배포 클릭 → 로그 확인

---

## 📞 도움말

- 📧 Email: roboholic84@gmail.com  
- 📖 전체 문서: README.md
- 🌐 Cloudflare Docs: https://developers.cloudflare.com/pages/

---

**마지막 업데이트: 2026-03-11**  
**버전: 1.0.0**